import React, { useState, useEffect } from "react";
import Telephone from "../../components/Appointment/Telephone";

export default function Booking() {


  return (
    <div className="container">
          <div className="telephone">
          <Telephone />
        </div>
    </div>
  );
}
