import React from "react";
import TopBar from "../../components/Topbar/TopBar";
import { SliderServices } from "../../components/Home/Slider/Slider";
import Footer from "../../components/Footer/Footer";
import Telephone from "../../components/Appointment/Telephone";
import Galleries from "../../components/Gallery/Gallery";
import Scroll from "../../components/ScrollToTop/Scroll";
import "./shop.css";

const Shop = () => {
  return (
    <div className="container">
      <section className="section1">
        <div className="background-image">
          <div className="container-item">
            <TopBar />

            <SliderServices title="Cửa Hàng" />
          </div>
        </div>
      </section>
      <div className="pricing-container">
        {/* <span className="subheading"> Của Hàng</span> */}
        <h2 className="h2-about"> Cửa Hàng SPaSimplify</h2>
        <div className="title">
          <br /> Tìm sản phẩm bạn muốn
        </div>
        <input type="text" placeholder="Tìm kiếm..." />
        <div className="pricing-item">
          <div className="list-shop">
            <div className="shop">
              <img
                src="https://chailohiepnguyen.com/wp-content/uploads/2019/12/ep-kim-len-hu-my-pham.png"
                alt=""
              />
              <div className="info">
                <h3>Body Milk</h3>
                <p>Sản phẩm dầu thơm từ tự nhiên không chất bảo quản</p>
                <h2>123.456đ</h2>
              </div>
              <div className="shop-btn">
                <button className="btn1">ADD TO CART</button>
              </div>
            </div>
            <div className="shop">
              <img
                src="https://chailohiepnguyen.com/wp-content/uploads/2019/12/ep-kim-len-hu-my-pham.png"
                alt=""
              />
              <div className="info">
                <h3>Body Milk</h3>
                <p>Sản phẩm dầu thơm từ tự nhiên không chất bảo quản</p>
                <h2>123.456đ</h2>
              </div>
              <div className="shop-btn">
                <button className="btn1">ADD TO CART</button>
              </div>
            </div>
            <div className="shop">
              <img
                src="https://chailohiepnguyen.com/wp-content/uploads/2019/12/ep-kim-len-hu-my-pham.png"
                alt=""
              />
              <div className="info">
                <h3>Body Milk</h3>
                <p>Sản phẩm dầu thơm từ tự nhiên không chất bảo quản</p>
                <h2>123.456đ</h2>
              </div>
              <div className="shop-btn">
                <button className="btn1">ADD TO CART</button>
              </div>
            </div>
            <div className="shop">
              <img
                src="https://chailohiepnguyen.com/wp-content/uploads/2019/12/ep-kim-len-hu-my-pham.png"
                alt=""
              />
              <div className="info">
                <h3>Body Milk</h3>
                <p>Sản phẩm dầu thơm từ tự nhiên không chất bảo quản</p>
                <h2>123.456đ</h2>
              </div>
              <div className="shop-btn">
                <button className="btn1">ADD TO CART</button>
              </div>
            </div>
            <div className="shop">
              <img
                src="https://chailohiepnguyen.com/wp-content/uploads/2019/12/ep-kim-len-hu-my-pham.png"
                alt=""
              />
              <div className="info">
                <h3>Body Milk</h3>
                <p>Sản phẩm dầu thơm từ tự nhiên không chất bảo quản</p>
                <h2>123.456đ</h2>
              </div>
              <div className="shop-btn">
                <button className="btn1">ADD TO CART</button>
              </div>
            </div>
            <div className="shop">
              <img
                src="https://chailohiepnguyen.com/wp-content/uploads/2019/12/ep-kim-len-hu-my-pham.png"
                alt=""
              />
              <div className="info">
                <h3>Body Milk</h3>
                <p>Sản phẩm dầu thơm từ tự nhiên không chất bảo quản</p>
                <h2>123.456đ</h2>
              </div>
              <div className="shop-btn">
                <button className="btn1">ADD TO CART</button>
              </div>
            </div>
            <div className="shop">
              <img
                src="https://chailohiepnguyen.com/wp-content/uploads/2019/12/ep-kim-len-hu-my-pham.png"
                alt=""
              />
              <div className="info">
                <h3>Body Milk</h3>
                <p>Sản phẩm dầu thơm từ tự nhiên không chất bảo quản</p>
                <h2>123.456đ</h2>
              </div>
              <div className="shop-btn">
                <button className="btn1">ADD TO CART</button>
              </div>
            </div>
            <div className="shop">
              <img
                src="https://chailohiepnguyen.com/wp-content/uploads/2019/12/ep-kim-len-hu-my-pham.png"
                alt=""
              />
              <div className="info">
                <h3>Body Milk</h3>
                <p>Sản phẩm dầu thơm từ tự nhiên không chất bảo quản</p>
                <h2>123.456đ</h2>
              </div>
              <div className="shop-btn">
                <button className="btn1">ADD TO CART</button>
              </div>
            </div>
            <div className="shop">
              <img
                src="https://chailohiepnguyen.com/wp-content/uploads/2019/12/ep-kim-len-hu-my-pham.png"
                alt=""
              />
              <div className="info">
                <h3>Body Milk</h3>
                <p>Sản phẩm dầu thơm từ tự nhiên không chất bảo quản</p>
                <h2>123.456đ</h2>
              </div>
              <div className="shop-btn">
                <button className="btn1">ADD TO CART</button>
              </div>
            </div>
          </div>
          <div className="side-bar">
            <div className="filter-price">
              <h3>Filter by price:</h3>
              <div>-------------------------</div>
              <p>FILTER</p>
            </div>

            <p> lastes-product</p>
            <ul className="list-product">
              <li className="lastes-product">
                <div className="lastes-product-img">
                  <img
                    src="https://chailohiepnguyen.com/wp-content/uploads/2019/12/ep-kim-len-hu-my-pham.png"
                    alt=""
                  />
                </div>
                <div className="lastes-product-price">
                  <p>Almond oil</p>
                  <h3>123.456 vnd</h3>
                </div>
              </li>
              <li className="lastes-product">
                <div className="lastes-product-img">
                  <img
                    src="https://chailohiepnguyen.com/wp-content/uploads/2019/12/ep-kim-len-hu-my-pham.png"
                    alt=""
                  />
                </div>
                <div className="lastes-product-price">
                  <p>Almond oil</p>
                  <h3>123.456 vnd</h3>
                </div>
              </li>
              <li className="lastes-product">
                <div className="lastes-product-img">
                  <img
                    src="https://chailohiepnguyen.com/wp-content/uploads/2019/12/ep-kim-len-hu-my-pham.png"
                    alt=""
                  />
                </div>
                <div className="lastes-product-price">
                  <p>Almond oil</p>
                  <h3>123.456 vnd</h3>
                </div>
              </li>
            </ul>
            <p>Categories</p>
            <ul className="Categories">
              <li>BATH SET</li>
              <li>BATH SOAP</li>
              <li>BEAUTY</li>
              <li>CLEANISNG</li>
              <li>COSMETICS</li>
              <li>DESIGN</li>
              <li>MOISTURIZING</li>
              <li>WELLNESS</li>
            </ul>
            <p>Tags</p>
            <ul className="tags">
              <li>BODY</li>
              <li>CARE</li>
              <li>DESIGN</li>
              <li>FACE</li>
              <li>IDEAS</li>
              <li>LOTION</li>
              <li>NEW</li>
              <li>OIL</li>
              <li>RELLAX</li>
              <li>SPA</li>
              <li>WOMENS</li>
            </ul>
            <p>Search</p>
            <div className="Search">
              <input placeholder="TYPE HERE" type="text" name="" id="" />
            </div>
          </div>
        </div>
      </div>
      <div className="telephone">
        <Telephone />
      </div>
      <Scroll />
      <Footer />
    </div>
  );
};

export default Shop;
